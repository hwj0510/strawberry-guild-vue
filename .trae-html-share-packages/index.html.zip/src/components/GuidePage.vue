<script setup>
import { ref, computed } from 'vue'
import PostCard from '@/components/PostCard.vue'
import { usePosts } from '@/composables/usePosts'

const props = defineProps({
  category: { type: String, required: true },
  title: { type: String, default: '攻略' },
  subtitle: { type: String, default: '' },
  bannerBg: { type: String, default: 'linear-gradient(135deg,#5b8def,#9b59b6)' },
  subTags: { type: Array, default: () => ['全部', '攻略', '求助', '推荐', '吐槽', '闲聊'] },
})

const { posts, toggleLike, toggleCollect } = usePosts()

const activeTag = ref('全部')
const sortBy = ref('latest')

const catPosts = computed(() => posts.value.filter((p) => p.category === props.category))

const allTags = computed(() => {
  const set = new Set()
  catPosts.value.forEach((p) => p.tags.forEach((t) => set.add(t)))
  return [...set]
})

const filteredPosts = computed(() => {
  let list = catPosts.value
  if (activeTag.value !== '全部') {
    list = list.filter((p) => p.tags.includes(activeTag.value))
  }
  const arr = [...list]
  if (sortBy.value === 'hot') {
    arr.sort((a, b) => b.likes - a.likes)
  } else {
    arr.sort((a, b) => b.createdAt - a.createdAt)
  }
  return arr
})

const topPosts = computed(() =>
  [...catPosts.value].sort((a, b) => b.likes - a.likes).slice(0, 5)
)
</script>

<template>
  <div class="guide-page">
    <!-- 顶部 Banner -->
    <div class="guide-banner" :style="{ background: bannerBg }">
      <h1 class="banner-title">{{ title }}</h1>
      <p class="banner-sub">{{ subtitle }}</p>
      <div class="banner-stat">共 {{ catPosts.length }} 篇攻略 · {{ allTags.length }} 个标签</div>
    </div>

    <div class="guide-layout">
      <div class="guide-main">
        <!-- 筛选 + 排序栏 -->
        <div class="filter-bar">
          <div class="filter-tags">
            <span
              v-for="t in subTags"
              :key="t"
              class="filter-tag"
              :class="{ active: activeTag === t }"
              @click="activeTag = t"
            >{{ t }}</span>
          </div>
          <el-radio-group v-model="sortBy" size="small">
            <el-radio-button value="latest">最新</el-radio-button>
            <el-radio-button value="hot">最热</el-radio-button>
          </el-radio-group>
        </div>

        <PostCard
          v-for="post in filteredPosts"
          :key="post.id"
          :post="post"
          @like="toggleLike"
          @collect="toggleCollect"
        />
        <el-empty v-if="!filteredPosts.length" description="该分类下暂无内容" />
      </div>

      <aside class="guide-side">
        <div class="side-card">
          <div class="card-head">
            <span class="card-title">🏆 本周热门</span>
          </div>
          <ol class="top-list">
            <li v-for="(p, i) in topPosts" :key="p.id" class="top-item">
              <span class="top-rank" :class="{ top: i < 3 }">{{ i + 1 }}</span>
              <div class="top-info">
                <div class="top-title">{{ p.title || p.content.slice(0, 20) }}</div>
                <div class="top-meta">{{ p.author }} · {{ p.likes }} 赞</div>
              </div>
            </li>
          </ol>
          <el-empty v-if="!topPosts.length" :image-size="60" description="暂无热门" />
        </div>

        <div class="side-card">
          <div class="card-head">
            <span class="card-title">🏷 热门标签</span>
          </div>
          <div class="tag-cloud">
            <span
              v-for="t in allTags"
              :key="t"
              class="cloud-tag"
              :class="{ active: activeTag === t }"
              @click="activeTag = t"
            >#{{ t }}</span>
          </div>
        </div>
      </aside>
    </div>
  </div>
</template>

<style scoped>
.guide-banner {
  border-radius: 14px;
  padding: 32px 28px;
  color: #fff;
  margin-bottom: 16px;
  box-shadow: 0 4px 16px rgba(0, 0, 0, 0.08);
}
.banner-title {
  font-size: 26px;
  font-weight: 700;
  margin: 0 0 8px;
}
.banner-sub {
  font-size: 14px;
  opacity: 0.92;
  margin: 0 0 12px;
}
.banner-stat {
  font-size: 13px;
  opacity: 0.85;
}
.guide-layout {
  display: flex;
  gap: 16px;
  align-items: flex-start;
}
.guide-main {
  flex: 1;
  min-width: 0;
}
.guide-side {
  width: 300px;
  flex-shrink: 0;
}
.filter-bar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  background: #fff;
  border-radius: 12px;
  padding: 10px 16px;
  margin-bottom: 12px;
  flex-wrap: wrap;
  gap: 10px;
}
.filter-tags {
  display: flex;
  gap: 6px;
  flex-wrap: wrap;
}
.filter-tag {
  padding: 5px 14px;
  font-size: 13px;
  color: #4e5969;
  background: #f2f3f5;
  border-radius: 14px;
  cursor: pointer;
  transition: all 0.15s;
}
.filter-tag:hover {
  background: #e8f0ff;
  color: #5b8def;
}
.filter-tag.active {
  background: #5b8def;
  color: #fff;
}
.side-card {
  background: #fff;
  border-radius: 12px;
  padding: 16px;
  margin-bottom: 12px;
}
.card-head {
  margin-bottom: 12px;
}
.card-title {
  font-size: 15px;
  font-weight: 700;
  color: #1f2329;
}
.top-list {
  list-style: none;
  padding: 0;
  margin: 0;
}
.top-item {
  display: flex;
  align-items: flex-start;
  gap: 10px;
  padding: 10px 0;
  border-bottom: 1px solid #f5f6f7;
  cursor: pointer;
}
.top-item:last-child {
  border-bottom: none;
}
.top-rank {
  width: 20px;
  text-align: center;
  font-size: 14px;
  font-weight: 700;
  color: #8a919f;
  flex-shrink: 0;
  padding-top: 2px;
}
.top-rank.top {
  color: #f56c6c;
}
.top-title {
  font-size: 13px;
  color: #4e5969;
  line-height: 1.5;
  overflow: hidden;
  text-overflow: ellipsis;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
}
.top-item:hover .top-title {
  color: #5b8def;
}
.top-meta {
  font-size: 11px;
  color: #8a919f;
  margin-top: 4px;
}
.tag-cloud {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
}
.cloud-tag {
  font-size: 12px;
  padding: 4px 10px;
  background: #f2f3f5;
  color: #4e5969;
  border-radius: 12px;
  cursor: pointer;
  transition: all 0.15s;
}
.cloud-tag:hover {
  background: #e8f0ff;
  color: #5b8def;
}
.cloud-tag.active {
  background: #5b8def;
  color: #fff;
}
</style>
