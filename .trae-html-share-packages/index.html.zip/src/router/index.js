import { createRouter, createWebHistory } from 'vue-router'
import MainLayout from '@/layout/MainLayout.vue'
import Home from '@/views/Home.vue'
import GameGuide from '@/views/GameGuide.vue'
import MovieGuide from '@/views/MovieGuide.vue'
import AIChat from '@/views/AIChat.vue'
import Login from '@/views/Login.vue'

// 路由配置
const routes = [
  {
    path: '/',
    component: MainLayout,
    children: [
      { path: '', name: 'home', component: Home },
      { path: 'game', name: 'game', component: GameGuide },
      { path: 'movie', name: 'movie', component: MovieGuide },
      { path: 'ai', name: 'ai', component: AIChat },
    ],
  },
  {
    path: '/login',
    name: 'login',
    component: Login,
  },
]

const router = createRouter({
  history: createWebHistory(),
  routes,
})

export default router
