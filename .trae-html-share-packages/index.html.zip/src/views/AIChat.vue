<script setup>
import { ref, nextTick, onMounted } from 'vue'
import { Promotion } from '@element-plus/icons-vue'
import { avatarColor, avatarText } from '@/utils/avatar'

const messages = ref([])
const input = ref('')
const typing = ref(false)
const listRef = ref(null)
const currentUser = '莓友'

const suggestions = [
  '推荐一款开放世界游戏',
  '《沙丘 2》讲了什么？',
  '怎么用 AI 写游戏评测？',
  '最近有什么好电影？',
]

function aiReply(text) {
  const t = text
  if (/你好|hi|hello|在吗|哈喽/.test(t))
    return '你好呀！我是莓攻略的 AI 姬～🍓 游戏攻略、影视解析、找片单，都可以问我哦！'
  if (/开放世界|塞尔达|巫师|原神|艾尔登/.test(t))
    return '开放世界强推《艾尔登法环》《巫师 3》《塞尔达传说：王国之泪》和《原神》。想要剧情向还是探索向？我可以再细化推荐～'
  if (/沙丘|影视|电影|片单|好电影/.test(t))
    return '近期口碑不错的有《沙丘 2》《奥本海默》《繁花》。我可以帮你梳理剧情伏笔，或者按科幻 / 悬疑 / 动画生成一份年度片单 🎬'
  if (/攻略|boss|打法|通关|卡关/.test(t))
    return '告诉我是哪款游戏的哪个 Boss，我可以帮你分析招式拆解、推荐配装和变身搭配，手残党也能通关！'
  if (/ai|写|评测|文案|提示词/.test(t))
    return '没问题！把游戏截图和基础设定发给我，我能帮你生成不同风格的评测文案，再由你人工润色就很完美啦 ✨'
  if (/谢谢|感谢|多谢/.test(t)) return '不客气～能帮到你我很开心！还有其他想聊的随时叫我 🍓'
  return '这个问题很有意思～你可以试着问我游戏攻略、影视解析，或者让我帮你写点什么，我随时在线！'
}

function scrollToBottom() {
  nextTick(() => {
    if (listRef.value) listRef.value.scrollTop = listRef.value.scrollHeight
  })
}

function pushMessage(role, text) {
  messages.value.push({
    role,
    text,
    time: new Date().toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' }),
  })
  scrollToBottom()
}

function send(text) {
  const content = (text ?? input.value).trim()
  if (!content || typing.value) return
  pushMessage('user', content)
  input.value = ''
  typing.value = true
  setTimeout(() => {
    typing.value = false
    pushMessage('ai', aiReply(content))
  }, 600 + Math.random() * 600)
}

onMounted(() => {
  pushMessage('ai', '你好呀！我是莓攻略的 AI 姬🍓，有什么游戏或影视方面的问题都可以问我～')
})
</script>

<template>
  <div class="chat-page">
    <div class="chat-window">
      <!-- 头部 -->
      <div class="chat-header">
        <div class="ai-profile">
          <el-avatar :size="42" class="ai-avatar">🤖</el-avatar>
          <div>
            <div class="ai-name">AI 姬</div>
            <div class="ai-status"><span class="online-dot"></span>在线 · 随时为你服务</div>
          </div>
        </div>
      </div>

      <!-- 消息列表 -->
      <div class="chat-list" ref="listRef">
        <div
          v-for="(msg, i) in messages"
          :key="i"
          class="msg-row"
          :class="msg.role"
        >
          <el-avatar
            v-if="msg.role === 'ai'"
            :size="34"
            class="ai-avatar small"
          >🤖</el-avatar>
          <div class="bubble-wrap">
            <div class="bubble" :class="msg.role">{{ msg.text }}</div>
            <div class="msg-time">{{ msg.time }}</div>
          </div>
          <el-avatar
            v-if="msg.role === 'user'"
            :size="34"
            :style="{ background: avatarColor(currentUser) }"
            class="user-avatar"
          >{{ avatarText(currentUser) }}</el-avatar>
        </div>

        <div v-if="typing" class="msg-row ai">
          <el-avatar :size="34" class="ai-avatar small">🤖</el-avatar>
          <div class="bubble ai typing">
            <span></span><span></span><span></span>
          </div>
        </div>
      </div>

      <!-- 推荐问题 -->
      <div v-if="messages.length <= 1" class="suggestions">
        <span class="sug-label">试试问我：</span>
        <el-tag
          v-for="s in suggestions"
          :key="s"
          class="sug-chip"
          effect="plain"
          round
          @click="send(s)"
        >{{ s }}</el-tag>
      </div>

      <!-- 输入区 -->
      <div class="chat-input">
        <el-input
          v-model="input"
          placeholder="输入你想问的问题，回车发送…"
          size="large"
          clearable
          @keyup.enter="send()"
        >
          <template #append>
            <el-button type="primary" :icon="Promotion" @click="send()">发送</el-button>
          </template>
        </el-input>
      </div>
    </div>
  </div>
</template>

<style scoped>
.chat-page {
  display: flex;
  justify-content: center;
}
.chat-window {
  width: 100%;
  max-width: 820px;
  height: calc(100vh - 140px);
  min-height: 560px;
  background: #fff;
  border-radius: 16px;
  display: flex;
  flex-direction: column;
  overflow: hidden;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.06);
}
.chat-header {
  padding: 16px 20px;
  border-bottom: 1px solid #f0f1f3;
  background: linear-gradient(135deg, #f0f5ff, #faf0ff);
}
.ai-profile {
  display: flex;
  align-items: center;
  gap: 12px;
}
.ai-avatar {
  background: linear-gradient(135deg, #9b59b6, #5b8def);
  display: flex;
  align-items: center;
  justify-content: center;
}
.ai-avatar.small {
  font-size: 18px;
}
.ai-name {
  font-size: 16px;
  font-weight: 700;
  color: #1f2329;
}
.ai-status {
  font-size: 12px;
  color: #8a919f;
  display: flex;
  align-items: center;
  gap: 5px;
  margin-top: 2px;
}
.online-dot {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: #67c23a;
  display: inline-block;
}
.chat-list {
  flex: 1;
  overflow-y: auto;
  padding: 20px;
  background: #fafbfc;
}
.msg-row {
  display: flex;
  gap: 10px;
  margin-bottom: 18px;
  align-items: flex-start;
}
.msg-row.user {
  flex-direction: row-reverse;
}
.bubble-wrap {
  max-width: 70%;
  display: flex;
  flex-direction: column;
}
.msg-row.user .bubble-wrap {
  align-items: flex-end;
}
.bubble {
  padding: 10px 14px;
  border-radius: 12px;
  font-size: 14px;
  line-height: 1.7;
  word-break: break-word;
}
.bubble.ai {
  background: #fff;
  border: 1px solid #eceff1;
  border-top-left-radius: 4px;
  color: #1f2329;
}
.bubble.user {
  background: #5b8def;
  color: #fff;
  border-top-right-radius: 4px;
}
.bubble.typing {
  display: inline-flex;
  gap: 4px;
  padding: 14px 16px;
}
.bubble.typing span {
  width: 7px;
  height: 7px;
  border-radius: 50%;
  background: #c0c4cc;
  animation: blink 1.2s infinite both;
}
.bubble.typing span:nth-child(2) {
  animation-delay: 0.2s;
}
.bubble.typing span:nth-child(3) {
  animation-delay: 0.4s;
}
@keyframes blink {
  0%, 80%, 100% { opacity: 0.3; }
  40% { opacity: 1; }
}
.msg-time {
  font-size: 11px;
  color: #b0b4bd;
  margin-top: 4px;
}
.user-avatar {
  color: #fff;
  font-weight: 600;
  flex-shrink: 0;
}
.suggestions {
  padding: 12px 20px;
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  align-items: center;
  border-top: 1px solid #f0f1f3;
  background: #fff;
}
.sug-label {
  font-size: 12px;
  color: #8a919f;
}
.sug-chip {
  cursor: pointer;
  transition: all 0.15s;
}
.sug-chip:hover {
  background: #5b8def;
  color: #fff;
  border-color: #5b8def;
}
.chat-input {
  padding: 14px 20px 18px;
  border-top: 1px solid #f0f1f3;
  background: #fff;
}
</style>
