<script setup>
import { ref, computed } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import { Refresh, Trophy, Film, Cpu, TrendCharts } from '@element-plus/icons-vue'
import PostCard from '@/components/PostCard.vue'
import PublishBox from '@/components/PublishBox.vue'
import { usePosts } from '@/composables/usePosts'

const router = useRouter()
const { posts, hotTopics, publishPost, toggleLike, toggleCollect } = usePosts()

const quickCards = [
  { title: '游戏攻略', desc: '海量通关心得 · Boss 打法', path: '/game', icon: Trophy, bg: 'linear-gradient(135deg,#5b8def,#7aa5f5)' },
  { title: '影视攻略', desc: '剧情解析 · 年度片单', path: '/movie', icon: Film, bg: 'linear-gradient(135deg,#9b59b6,#b370cc)' },
  { title: 'AI 聊天', desc: 'AI 姬在线陪聊答疑', path: '/ai', icon: Cpu, bg: 'linear-gradient(135deg,#f39c12,#f5b041)' },
  { title: '热门榜单', desc: '社区热议一网打尽', path: '/', icon: TrendCharts, bg: 'linear-gradient(135deg,#e74c3c,#ec7063)' },
]

const tabs = [
  { key: 'follow', label: '关注' },
  { key: 'recommend', label: '推荐' },
  { key: '游戏', label: '游戏' },
  { key: '影视', label: '影视' },
  { key: 'AI', label: 'AI' },
]
const activeTab = ref('recommend')

const filteredPosts = computed(() => {
  const t = activeTab.value
  if (t === 'follow' || t === 'recommend') return posts.value
  return posts.value.filter((p) => p.category === t)
})

function inferCategory(tags) {
  if (tags.includes('游戏')) return '游戏'
  if (tags.includes('影视')) return '影视'
  if (tags.includes('AI')) return 'AI'
  return '推荐'
}

function handlePublish({ content, tags }) {
  const category = inferCategory(tags)
  publishPost({ author: '莓友', content, tags, category })
  activeTab.value = 'recommend'
  ElMessage.success('发布成功，快去看看吧～')
}

function rankClass(rank) {
  if (rank <= 3) return 'top'
  return ''
}
</script>

<template>
  <div class="home">
    <div class="home-layout">
      <!-- 左侧主内容 -->
      <div class="home-main">
        <!-- 快捷入口卡片 -->
        <div class="quick-grid">
          <div
            v-for="card in quickCards"
            :key="card.title"
            class="quick-card"
            :style="{ background: card.bg }"
            @click="router.push(card.path)"
          >
            <el-icon :size="28" color="#fff"><component :is="card.icon" /></el-icon>
            <div class="quick-text">
              <div class="quick-title">{{ card.title }}</div>
              <div class="quick-desc">{{ card.desc }}</div>
            </div>
          </div>
        </div>

        <!-- 发帖框 -->
        <PublishBox @publish="handlePublish" />

        <!-- 分类 Tab 栏 -->
        <div class="tab-bar">
          <div class="tabs">
            <span
              v-for="tab in tabs"
              :key="tab.key"
              class="tab"
              :class="{ active: activeTab === tab.key }"
              @click="activeTab = tab.key"
            >{{ tab.label }}</span>
          </div>
          <div class="tab-extra">
            <el-icon><Refresh /></el-icon>
            <span>刷新</span>
          </div>
        </div>

        <!-- 帖子列表 -->
        <PostCard
          v-for="post in filteredPosts"
          :key="post.id"
          :post="post"
          @like="toggleLike"
          @collect="toggleCollect"
        />
        <el-empty v-if="!filteredPosts.length" description="暂无内容，快来发布第一条吧～" />
      </div>

      <!-- 右侧边栏 -->
      <aside class="home-side">
        <div class="hot-card">
          <div class="card-head">
            <span class="card-title">🔥 全站热榜</span>
            <a class="more">更多 ›</a>
          </div>
          <ol class="hot-list">
            <li v-for="topic in hotTopics" :key="topic.rank" class="hot-item">
              <span class="hot-rank" :class="rankClass(topic.rank)">{{ topic.rank }}</span>
              <span class="hot-title">{{ topic.title }}</span>
              <span class="hot-heat">{{ topic.heat }}</span>
            </li>
          </ol>
        </div>

        <div class="about-card">
          <div class="card-head">
            <span class="card-title">🍓 关于莓攻略</span>
          </div>
          <p class="about-text">
            这里聚集了一群热爱游戏与影视的小伙伴，分享攻略、交流心得，还有 AI 姬随时陪你聊天。遇到卡关？想找片单？来这里就对了！
          </p>
          <el-button type="primary" plain size="small" @click="router.push('/ai')">找 AI 姬聊聊</el-button>
        </div>
      </aside>
    </div>
  </div>
</template>

<style scoped>
.home-layout {
  display: flex;
  gap: 16px;
  align-items: flex-start;
}
.home-main {
  flex: 1;
  min-width: 0;
}
.home-side {
  width: 300px;
  flex-shrink: 0;
  position: sticky;
  top: 76px;
}
.quick-grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 12px;
  margin-bottom: 12px;
}
.quick-card {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 16px;
  border-radius: 12px;
  color: #fff;
  cursor: pointer;
  transition: transform 0.2s, box-shadow 0.2s;
}
.quick-card:hover {
  transform: translateY(-2px);
  box-shadow: 0 6px 18px rgba(0, 0, 0, 0.15);
}
.quick-title {
  font-size: 15px;
  font-weight: 700;
}
.quick-desc {
  font-size: 12px;
  opacity: 0.9;
  margin-top: 2px;
}
.tab-bar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  background: #fff;
  border-radius: 12px;
  padding: 0 16px;
  margin-bottom: 12px;
  height: 48px;
}
.tabs {
  display: flex;
  gap: 4px;
}
.tab {
  padding: 0 14px;
  height: 48px;
  line-height: 48px;
  font-size: 15px;
  color: #4e5969;
  cursor: pointer;
  position: relative;
  transition: color 0.2s;
}
.tab:hover {
  color: #5b8def;
}
.tab.active {
  color: #5b8def;
  font-weight: 600;
}
.tab.active::after {
  content: '';
  position: absolute;
  left: 14px;
  right: 14px;
  bottom: 0;
  height: 3px;
  background: #5b8def;
  border-radius: 3px 3px 0 0;
}
.tab-extra {
  display: flex;
  align-items: center;
  gap: 4px;
  font-size: 13px;
  color: #8a919f;
  cursor: pointer;
}
.tab-extra:hover {
  color: #5b8def;
}
.hot-card,
.about-card {
  background: #fff;
  border-radius: 12px;
  padding: 16px;
  margin-bottom: 12px;
}
.card-head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 12px;
}
.card-title {
  font-size: 15px;
  font-weight: 700;
  color: #1f2329;
}
.more {
  font-size: 12px;
  color: #8a919f;
  cursor: pointer;
  text-decoration: none;
}
.more:hover {
  color: #5b8def;
}
.hot-list {
  list-style: none;
  padding: 0;
  margin: 0;
}
.hot-item {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 8px 0;
  border-bottom: 1px solid #f5f6f7;
  cursor: pointer;
}
.hot-item:last-child {
  border-bottom: none;
}
.hot-item:hover .hot-title {
  color: #5b8def;
}
.hot-rank {
  width: 20px;
  text-align: center;
  font-size: 14px;
  font-weight: 700;
  color: #8a919f;
  flex-shrink: 0;
}
.hot-rank.top {
  color: #f56c6c;
}
.hot-title {
  flex: 1;
  font-size: 13px;
  color: #4e5969;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  transition: color 0.2s;
}
.hot-heat {
  font-size: 12px;
  color: #8a919f;
  flex-shrink: 0;
}
.about-text {
  font-size: 13px;
  color: #4e5969;
  line-height: 1.7;
  margin: 0 0 12px;
}
</style>
